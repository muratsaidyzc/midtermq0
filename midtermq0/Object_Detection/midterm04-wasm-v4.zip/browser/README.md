# Running your impulse using WebAssembly in the browser

For more information see the documentation at https://docs.edgeimpulse.com/docs/through-webassembly-browser

To start, open a terminal or command prompt and run:

```
$ python3 server.py
```

Then open http://localhost:8082 in a browser to see the application.
